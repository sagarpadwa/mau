#include <stdio.h>

#define MAX_VERTICES 100

int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES];

void initializeGraph(int vertices) {
    // Initialize the adjacency matrix with all zeros
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            adjacencyMatrix[i][j] = 0;
        }
    }
}

void addEdge(int source, int destination) {
    // Add the edge to the adjacency matrix
    adjacencyMatrix[source][destination] = 1;
    adjacencyMatrix[destination][source] = 1; // For undirected graphs
}

void displayAdjacencyMatrix(int vertices) {
    // Display the adjacency matrix
    printf("Adjacency Matrix:\n");
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            printf("%d ", adjacencyMatrix[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int vertices, edges, source, destination;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &vertices);

    initializeGraph(vertices);

    printf("Enter the number of edges in the graph: ");
    scanf("%d", &edges);

    printf("Enter the edges (source destination):\n");
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &source, &destination);
        addEdge(source, destination);
    }

    displayAdjacencyMatrix(vertices);

    return 0;
}
