#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

// Queue implementation
typedef struct {
    int items[MAX_VERTICES];
    int front;
    int rear;
} Queue;

// Function prototypes
void enqueue(Queue *q, int value);
int dequeue(Queue *q);
int isEmpty(Queue *q);
void BFS(int vertex, int numVertices, int adjacencyMatrix[][MAX_VERTICES], int visited[]);

// Function to enqueue an element into the queue
void enqueue(Queue *q, int value) {
    q->rear++;
    q->items[q->rear] = value;
}

// Function to dequeue an element from the queue
int dequeue(Queue *q) {
    int item = q->items[q->front];
    q->front++;
    return item;
}

// Function to check if the queue is empty
int isEmpty(Queue *q) {
    return q->front > q->rear;
}

// Function to perform Breadth First Search (BFS) traversal
void BFS(int vertex, int numVertices, int adjacencyMatrix[][MAX_VERTICES], int visited[]) {
    Queue q;
    q.front = 0;
    q.rear = -1;

    visited[vertex] = 1; // Mark the current vertex as visited
    enqueue(&q, vertex); // Enqueue the current vertex

    printf("Breadth First Search Traversal: ");

    while (!isEmpty(&q)) {
        int currentVertex = dequeue(&q);
        printf("%d ", currentVertex);

        // Traverse all adjacent vertices of the current vertex
        for (int i = 0; i < numVertices; i++) {
            if (adjacencyMatrix[currentVertex][i] && !visited[i]) {
                visited[i] = 1;
                enqueue(&q, i);
            }
        }
    }
    printf("\n");
}

int main() {
    int numVertices, numEdges;

    // Accept the number of vertices and edges of the graph
    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &numVertices);
    printf("Enter the number of edges in the graph: ");
    scanf("%d", &numEdges);

    // Adjacency matrix to represent the graph
    int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES] = {0};

    // Accept the edges of the graph and store them in the adjacency matrix
    printf("Enter the edges (vertex1 vertex2):\n");
    for (int i = 0; i < numEdges; i++) {
        int vertex1, vertex2;
        scanf("%d %d", &vertex1, &vertex2);
        adjacencyMatrix[vertex1][vertex2] = 1;
        adjacencyMatrix[vertex2][vertex1] = 1; // Assuming undirected graph
    }

    // Array to keep track of visited vertices during BFS traversal
    int visited[MAX_VERTICES] = {0};

    // Perform BFS traversal starting from each vertex
    for (int i = 0; i < numVertices; i++) {
        if (!visited[i]) {
            BFS(i, numVertices, adjacencyMatrix, visited);
        }
    }

    return 0;
}
