#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 10

// Structure to represent a hash table entry
struct Entry {
    int key;
    char data[100];
    int isOccupied;
};

// Hash function
int hash(int key) {
    return key % SIZE;
}

// Function to insert an element into the hash table
void insert(struct Entry table[], int key, char data[]) {
    int index = hash(key);

    // Linear probing to handle collisions
    while (table[index].isOccupied) {
        index = (index + 1) % SIZE;
    }

    // Insert the element
    table[index].key = key;
    strcpy(table[index].data, data);
    table[index].isOccupied = 1;

    printf("Element with key %d inserted successfully.\n", key);
}

// Function to search for an element in the hash table
void search(struct Entry table[], int key) {
    int index = hash(key);

    // Linear probing to handle collisions
    while (table[index].isOccupied && table[index].key != key) {
        index = (index + 1) % SIZE;
    }

    if (table[index].isOccupied && table[index].key == key) {
        printf("Element found at index %d: Key = %d, Data = %s\n", index, table[index].key, table[index].data);
    } else {
        printf("Element with key %d not found.\n", key);
    }
}

// Function to display the contents of the hash table
void display(struct Entry table[]) {
    printf("Hash Table Contents:\n");
    for (int i = 0; i < SIZE; i++) {
        if (table[i].isOccupied) {
            printf("Index %d: Key = %d, Data = %s\n", i, table[i].key, table[i].data);
        } else {
            printf("Index %d: Empty\n", i);
        }
    }
}

int main() {
    struct Entry table[SIZE] = {0}; // Initialize all entries as empty

    int choice, key;
    char data[100];

    do {
        printf("\nMenu:\n");
        printf("1. Insert\n");
        printf("2. Search\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter key: ");
                scanf("%d", &key);
                printf("Enter data: ");
                scanf("%s", data);
                insert(table, key, data);
                break;
            case 2:
                printf("Enter key to search: ");
                scanf("%d", &key);
                search(table, key);
                break;
            case 3:
                display(table);
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}
