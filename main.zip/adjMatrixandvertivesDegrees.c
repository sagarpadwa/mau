#include <stdio.h>

#define MAX_VERTICES 100

int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES];

void initializeGraph(int vertices) {
    // Initialize the adjacency matrix with all zeros
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            adjacencyMatrix[i][j] = 0;
        }
    }
}

void addEdge(int source, int destination) {
    // Add the edge to the adjacency matrix
    adjacencyMatrix[source][destination] = 1;
}

void printIndegreeOutdegree(int vertices) {
    printf("Vertex\tIndegree\tOutdegree\tTotal Degree\n");
    for (int i = 0; i < vertices; i++) {
        int indegree = 0, outdegree = 0;

        // Calculate the indegree of the vertex
        for (int j = 0; j < vertices; j++) {
            indegree += adjacencyMatrix[j][i];
        }

        // Calculate the outdegree of the vertex
        for (int j = 0; j < vertices; j++) {
            outdegree += adjacencyMatrix[i][j];
        }

        int totalDegree = indegree + outdegree;

        // Print the indegree, outdegree, and total degree of the vertex
        printf("%d\t%d\t\t%d\t\t%d\n", i, indegree, outdegree, totalDegree);
    }
}

int main() {
    int vertices, edges, source, destination;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &vertices);

    initializeGraph(vertices);

    printf("Enter the number of edges in the graph: ");
    scanf("%d", &edges);

    printf("Enter the edges (source destination):\n");
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &source, &destination);
        addEdge(source, destination);
    }

    printf("\nIndegree, Outdegree, and Total Degree of vertices:\n");
    printIndegreeOutdegree(vertices);

    return 0;
}
