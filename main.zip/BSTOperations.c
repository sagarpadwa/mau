#include <stdio.h>
#include <stdlib.h>

// Binary Search Tree Node
typedef struct Node {
    int data;
    struct Node *left;
    struct Node *right;
} Node;

// Function prototypes
Node* createNode(int data);
Node* insert(Node* root, int data);
void preorder(Node* root);

// Create a new node
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Insert a node into BST
Node* insert(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    if (data < root->data) {
        root->left = insert(root->left, data);
    } else if (data > root->data) {
        root->right = insert(root->right, data);
    }
    return root;
}

// Preorder traversal of BST
void preorder(Node* root) {
    if (root != NULL) {
        printf("%d ", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}

int main() {
    Node* root = NULL;
    int choice, data;

    printf("Binary Search Tree Operations\n");
    printf("1. Create\n");
    printf("2. Insert\n");
    printf("3. Preorder Traversal\n");
    printf("4. Exit\n");

    do {
        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the root data: ");
                scanf("%d", &data);
                root = createNode(data);
                printf("Binary search tree created with root %d.\n", data);
                break;
            case 2:
                if (root == NULL) {
                    printf("Please create a binary search tree first.\n");
                } else {
                    printf("Enter data to insert: ");
                    scanf("%d", &data);
                    root = insert(root, data);
                    printf("%d inserted into the binary search tree.\n", data);
                }
                break;
            case 3:
                if (root == NULL) {
                    printf("Please create a binary search tree first.\n");
                } else {
                    printf("Preorder traversal: ");
                    preorder(root);
                    printf("\n");
                }
                break;
            case 4:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please enter a valid option.\n");
        }
    } while (choice != 4);

    return 0;
}
1