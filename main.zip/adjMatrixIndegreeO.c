#include <stdio.h>

#define MAX_VERTICES 100

int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES];

void initializeGraph(int vertices) {
    // Initialize the adjacency matrix with all zeros
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            adjacencyMatrix[i][j] = 0;
        }
    }
}

void addEdge(int source, int destination) {
    // Add the edge to the adjacency matrix
    adjacencyMatrix[source][destination] = 1;
}

void printIndegree(int vertices) {
    int indegree[MAX_VERTICES] = {0};

    // Calculate the indegree of each vertex
    for (int i = 0; i < vertices; i++) {
        for (int j = 0; j < vertices; j++) {
            indegree[j] += adjacencyMatrix[i][j];
        }
    }

    // Print the indegree of each vertex
    printf("Vertex \t Indegree\n");
    for (int i = 0; i < vertices; i++) {
        printf("%d \t %d\n", i, indegree[i]);
    }
}

int main() {
    int vertices, edges, source, destination;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &vertices);

    initializeGraph(vertices);

    printf("Enter the number of edges in the graph: ");
    scanf("%d", &edges);

    printf("Enter the edges (source destination):\n");
    for (int i = 0; i < edges; i++) {
        scanf("%d %d", &source, &destination);
        addEdge(source, destination);
    }

    printf("\nIndegree of vertices:\n");
    printIndegree(vertices);

    return 0;
}
3
