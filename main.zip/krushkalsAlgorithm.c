#include <stdio.h>
#include <stdlib.h>

// Structure to represent an edge in the graph
struct Edge {
    int src, dest, weight;
};

// Structure to represent a subset for union-find
struct Subset {
    int parent;
    int rank;
};

// Function to create a graph of V vertices and E edges
struct Edge* createGraph(int V, int E) {
    struct Edge* graph = (struct Edge*)malloc(E * sizeof(struct Edge));
    return graph;
}

// Function to find the parent of a vertex using path compression
int find(struct Subset subsets[], int i) {
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}

// Function to perform union of two subsets using rank
void Union(struct Subset subsets[], int x, int y) {
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);

    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

// Function to implement Kruskal's algorithm
void KruskalMST(struct Edge* graph, int V, int E) {
    // Allocate memory for creating V subsets
    struct Subset* subsets = (struct Subset*)malloc(V * sizeof(struct Subset));

    // Initialize subsets
    for (int v = 0; v < V; v++) {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    // Sort all edges in non-decreasing order of their weight
    qsort(graph, E, sizeof(graph[0]), [](const void* a, const void* b) {
        struct Edge* a_edge = (struct Edge*)a;
        struct Edge* b_edge = (struct Edge*)b;
        return a_edge->weight - b_edge->weight;
    });

    // Initialize result MST
    struct Edge* result = (struct Edge*)malloc((V - 1) * sizeof(struct Edge));
    int e = 0; // Index for result

    // Index for sorted edges
    int i = 0;

    // Number of edges to be taken is equal to V-1
    while (e < V - 1 && i < E) {
        // Take the smallest edge and increment the index for the next iteration
        struct Edge next_edge = graph[i++];

        int x = find(subsets, next_edge.src);
        int y = find(subsets, next_edge.dest);

        // If including this edge does not cause cycle, include it in the result and increment the index
        if (x != y) {
            result[e++] = next_edge;
            Union(subsets, x, y);
        }
    }

    // Print the edges of MST
    printf("Edges of Minimum Spanning Tree:\n");
    for (i = 0; i < e; ++i)
        printf("%d -- %d == %d\n", result[i].src, result[i].dest, result[i].weight);

    free(subsets);
    free(result);
}

int main() {
    int V, E; // V is the number of vertices and E is the number of edges

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &V);

    printf("Enter the number of edges in the graph: ");
    scanf("%d", &E);

    struct Edge* graph = createGraph(V, E);

    printf("Enter the edges and their weights (source destination weight):\n");
    for (int i = 0; i < E; ++i)
        scanf("%d %d %d", &graph[i].src, &graph[i].dest, &graph[i].weight);

    KruskalMST(graph, V, E);

    free(graph);

    return 0;
}
s