#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTICES 100

// Function prototypes
void DFS(int vertex, int numVertices, int adjacencyMatrix[][MAX_VERTICES], int visited[]);

// Function to traverse the graph using Depth First Search (DFS) traversal
void DFS(int vertex, int numVertices, int adjacencyMatrix[][MAX_VERTICES], int visited[]) {
    visited[vertex] = 1; // Mark the current vertex as visited
    printf("%d ", vertex); // Print the current vertex
    // Traverse all adjacent vertices of the current vertex
    for (int i = 0; i < numVertices; i++) {
        if (adjacencyMatrix[vertex][i] && !visited[i]) {
            DFS(i, numVertices, adjacencyMatrix, visited);
        }
    }
}

int main() {
    int numVertices, numEdges;

    // Accept the number of vertices and edges of the graph
    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &numVertices);
    printf("Enter the number of edges in the graph: ");
    scanf("%d", &numEdges);

    // Adjacency matrix to represent the graph
    int adjacencyMatrix[MAX_VERTICES][MAX_VERTICES] = {0};

    // Accept the edges of the graph and store them in the adjacency matrix
    printf("Enter the edges (vertex1 vertex2):\n");
    for (int i = 0; i < numEdges; i++) {
        int vertex1, vertex2;
        scanf("%d %d", &vertex1, &vertex2);
        adjacencyMatrix[vertex1][vertex2] = 1;
        adjacencyMatrix[vertex2][vertex1] = 1; // Assuming undirected graph
    }

    // Array to keep track of visited vertices during DFS traversal
    int visited[MAX_VERTICES] = {0};

    // Perform DFS traversal starting from each vertex
    printf("DFS Traversal:\n");
    for (int i = 0; i < numVertices; i++) {
        if (!visited[i]) {
            DFS(i, numVertices, adjacencyMatrix, visited);
        }
    }
    printf("\n");

    return 0;
}
3